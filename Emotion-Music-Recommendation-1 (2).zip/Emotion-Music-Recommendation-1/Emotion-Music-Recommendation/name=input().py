name=input()
age=int(input())
cgpa=float(input())
grade=input()[0]
print("Name: {}".format(name))
print("Age: {}".format(age))
print("CGPA: {:.2f}".format(cgpa))
print("Grade: {}".format(grade))